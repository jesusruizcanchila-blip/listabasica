package com.mycompany.listabasica;

import java.util.Scanner;

/**
 * EJERCICIO 1 — Lista Enlazada Básica (enteros)
 *
 * Conceptos ilustrados:
 *   - Clase auto-referenciada : Nodo (contiene una referencia a otro Nodo)
 *   - Nodo                    : unidad básica con dato + enlace
 *   - Campo de enlace         : campo "enlace" dentro de cada Nodo
 *   - Enlace                  : la conexión entre nodos consecutivos
 */
public class Main {

    public static void main(String[] args) {

        // ── 1. Crear la lista enlazada (vacía) y el Scanner ────────────────
        ListaEnlazada lista = new ListaEnlazada();
        Scanner sc = new Scanner(System.in);

        System.out.println("=== EJERCICIO 1 — LISTA ENLAZADA BASICA ===\n");

        // ── 2. Insertar nodos (datos por pantalla) ─────────────────────────
        System.out.print("¿Cuantos datos quieres insertar? ");
        int n = sc.nextInt();

        for (int i = 1; i <= n; i++) {
            System.out.print("Dato " + i + ": ");
            lista.insertar(sc.nextInt());
        }
        lista.mostrar();

        /*
         * Internamente los nodos se ven así:
         *
         *   ┌───────────┐    ┌───────────┐    ┌───────────┐
         *   │ dato: 10  │    │ dato: 20  │    │ dato: 30  │  ...
         *   │ enlace: ──┼───▶│ enlace: ──┼───▶│ enlace: ──┼───▶ null
         *   └───────────┘    └───────────┘    └───────────┘
         *      Nodo 1            Nodo 2            Nodo 3
         *
         *  "enlace" es el CAMPO DE ENLACE → hace que Nodo sea AUTO-REFERENCIADA
         */

        // ── 3. Tamaño ──────────────────────────────────────────────────────
        System.out.println("\n Tamanio de la lista: " + lista.tamanio());

        // ── 4. Buscar ──────────────────────────────────────────────────────
        System.out.print("\n Dato a buscar: ");
        int buscado = sc.nextInt();
        System.out.println(" Buscar " + buscado + ": " + lista.buscar(buscado));

        // ── 5. Eliminar ────────────────────────────────────────────────────
        System.out.print("\n Dato a eliminar: ");
        int eliminado = sc.nextInt();
        lista.eliminar(eliminado);
        lista.mostrar();

        // ── 6. Ver estructura de un Nodo manualmente ───────────────────────
        System.out.println("\n=== ANATOMIA DE UN NODO ===");
        Nodo n1 = new Nodo(100);
        Nodo n2 = new Nodo(200);
        Nodo n3 = new Nodo(300);

        n1.enlace = n2;   // n1 → n2
        n2.enlace = n3;   // n2 → n3

        System.out.println("n1.dato              = " + n1.dato);
        System.out.println("n1.enlace            = " + n1.enlace);
        System.out.println("n1.enlace.enlace     = " + n1.enlace.enlace);
        System.out.println("cadena: " + n1 + " → " + n2 + " → " + n3 + " → null");

        sc.close();
    }
}